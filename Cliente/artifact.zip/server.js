"use strict";

/*
    Software Avanzado
    Práctica 3
    Microservicio Clientes
    José Francisco Puac Ixcamparic
    201700342
*/
// Uso de la libreria Express
var express = require('express'); // Puerto 3001


var puerto = process.env.PORT || 3001; // Utilizacion de cors

var cors = require('cors'); // Utilizacion de las rutas especificadas en el archivo client.route


var routes = require('./routes/client.route'); // Directrices de la app


var app = express();
app.use(cors());
app.use(express.urlencoded({
  extended: false
}));
app.use(express.json());
app.use('/', routes); // Inicializacion del servidor

app.listen(puerto, function () {
  console.log("Client server running in port " + puerto);
});