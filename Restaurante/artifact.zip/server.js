"use strict";

/*
    Software Avanzado
    Práctica 3
    Microservicio Restaurante
    José Francisco Puac Ixcamparic
    201700342
*/
// Uso de la libreria Express
var express = require('express'); // Puerto 3002


var puerto = process.env.PORT || 3002; // Utilizacion de cors

var cors = require('cors'); // Utilizacion de las rutas especificadas en el archivo restaurant.route


var routes = require('./routes/restaurant.route'); // Directrices de la app


var app = express();
app.use(cors());
app.use(express.urlencoded({
  extended: false
}));
app.use(express.json());
app.use('/', routes); // Inicializacion del servidor

app.listen(puerto, function () {
  console.log("Restaurant server running in port " + puerto);
});